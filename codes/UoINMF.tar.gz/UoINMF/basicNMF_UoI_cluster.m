function [mdlstrct] = basicNMF_UoI_cluster(A,maxk,b)
%[mdlstrct] = basicNMF_UoI(A,k)
%Implements the basicNMFUoI algorithm using bootstrap sampling for selection and Bagged
%OLS for estimation. Uses maximum correlation to remove near duplicates
%A: Input nonegative matrix: n instances X d variables
%maxk: maximum rank k for the decomposition

verb=1; %verbose display of iterations
[n,d]=size(A);
%% parameters for the procedure
mdlstrct.parms.nrnd = 20; %number of random draws from the data for cross-validation on final bagged estimates
mdlstrct.parms.nbootE = 10; %number of bootstrap samples for bagging (estimation)
mdlstrct.parms.nbootS = b; %number of bootstrap samples for selection
mdlstrct.parms.cvlfrct = 0.9; %fraction of data used for cross-validation of bagged OLS
mdlstrct.parms.rndfrct = 0.8; %fraction of data used for OLS fitting, 1-rndfrct used for selecting best model support
mdlstrct.parms.rndfrctL = 0.9; %fraction of data used for Lasso fitting
mdlstrct.parms.nMP = 1; %number of different rank
mdlstrct.parms.k0 = maxk; %range of rank

tic
%% main loop over different rank k
for i = 1:mdlstrct.parms.nMP %
    k=mdlstrct.parms.k0(i);
    H2=[];
    %% For different bootstraps, generate samples and compute basic NMF
    for c = 1:mdlstrct.parms.nbootS
        if verb
            if mod(c,10)==0; disp(c); end
        end
        %the bootstrap sample
        rndsd = randperm(n); rndsd = rndsd(1:round(mdlstrct.parms.rndfrctL*n));
        % get W and H for different k and different
        [Wtemp(:,:,c),H(:,:,c),D(c)]=nnmf(A(rndsd,:),k);
        randind(:,c)=rndsd;
        H2=[H2;(H(:,:,c))];
    end
    
    %% Choose best bases based correlation.
    % Uses maximum correlation and kmeans clustering to choose th best
    % bases
    H2(all( ~any(H2'), 1 ),:) = [];%remove zero bases
    mdlstrct.H2=H2;
    mdlstrct.Wtemp=Wtemp;
   % return;
    H2 = normalize_H(H2,2);
    [idx,Cen]=kmeans(H2,k,'Distance','cosine');
    j1=1;
    for j=1:k
        idtemp=find(idx==j);
        if(length(idtemp)>mdlstrct.parms.nbootS+1)
            H1=H2(idtemp,:);
            ktemp=ceil(size(H1,1)/mdlstrct.parms.nbootS);
            [idx2,Cen2]=kmeans(H1,ktemp,'Distance','cosine');
            for jtemp=1:ktemp
                %H4=H1(idx2==jtemp,:);
                %H3(j1,:)=min(H4);
                H3(j1,:)=Cen2(jtemp,:);
               j1=j1+1;
            end
        else
        %H1=H2(idtemp,:);
        %H3(j1,:)=min(H1);
         H3(j1,:)=Cen(j,:);
        j1=j1+1;
        end
    end
    H3 = normalize_H(H3,2);
%     H3=normc(H3')';
%     C1=H3*H3'; C1=C1-diag(diag(C1));
    C1=abs(corr(H3'))-eye(size(H3,1));
   %C1=abs(corr(H3',A'));
    [~,id]=sort(sum(C1,2),'ascend');
    % [~,id]=sort(var(H3,[],2),'descend');
    bestid=id(1:k);
    %h=min(A);
    %mdlstrct.H_int(i).H=[H3(bestidx,:);h];
    mdlstrct.H_int(i).H=H3(bestid,:);
    %% update W based on the best bases H
    for c = 1:mdlstrct.parms.nbootS
        rndsd= randind(:,c);
        for l=1:length(rndsd)
            W(rndsd(l),:,c)= lsqnonneg(mdlstrct.H_int(i).H',A(rndsd(l),:)')';
        end
    end
    randind=randind(:,1:end);
    
    %% Do the intersection operation
    for l=1:n
        [r,c]=find(randind==l);
        if(~isempty(r))
            for j=1:length(r)  %for each bootstrap sample
                w = find(W(l,:,c(j)));
                if j==1, intw = w; end
                intw = intersect(intw,w); %support is intersection of supports across bootstrap samples
            end
            intWid{l}=intw;
        else
            intWid{l}=[];
        end
    end
    mdlstrct.W_intid(i).Wid=intWid;
    mdlstrct.D_int(i).D=D;
    clear W; clear H;clear D; clear C, clear intWid;
end
%% Estimation of weights (Union)
%%%get bootstrap estimates for the support associated with each
%%%rank k
for c=1:mdlstrct.parms.nbootE %number of bootstrap samples for aggregation
    rndsd = randperm(n);rndsd = rndsd(1:round(mdlstrct.parms.rndfrct*n));%Btraining data
    for i=1:mdlstrct.parms.nMP %for each rank
        for l=1:length(rndsd)
            wind=mdlstrct.W_intid(i).Wid{rndsd(l)};
            if(~isempty(wind))
                zdids = setdiff(1:mdlstrct.parms.k0(i),wind);
                %calculate parameters based on reduced model support
                mdlstrct.opt.param(i).W(l,wind,c)= lsqnonneg(mdlstrct.H_int(i).H(wind,:)',A(rndsd(l),:)')';
                mdlstrct.opt.param(i).W(l,zdids,c) = 0;
            else
                mdlstrct.opt.param(i).W(l,1:mdlstrct.parms.k0(i),c) = 0;
            end
        end
        %caclulate error in reconstruction for
        %each bootstrap sample
        err = norm(A(rndsd,:)-mdlstrct.opt.param(i).W(:,:,c)*mdlstrct.H_int(i).H,'fro');
        mdlstrct.opt.err(c,i) =err;
    end
    randind2(:,c)=rndsd;
end
%%%get bagged estimate of model associated with best regularization parameter
%for each bootstrap sample, find regularization parameter that gave best results
[~,id] = min(mean(mdlstrct.opt.err,1));
for l=1:n
    [r1,c1]=find(randind2==l);
    for j=1:length(r1)  %for each bootstrap sample
        W_bag(j,:) = mdlstrct.opt.param(id).W(r1(j),:,c1(j));
    end
    Wopt(l,:)=median(W_bag);
end
mdlstrct.opt.Wopt = Wopt;%bagged estimates of model parameters
mdlstrct.opt.Hopt = mdlstrct.H_int(id).H;

toc
