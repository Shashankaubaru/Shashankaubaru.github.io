clc
close all
clear all

addpath 'nmfv1_4/'
addpath 'nmflib/'


%% Get Data
load('Y.mat');

sigma=[0.0001,0.001,0.01,0.2];

X=reshape(mat2gray(Y),[],256,1)';

load('Exact_16bases_swimmer.mat');

%% Create noisy data
A=[];
for l=1:10
    X1=X+sigma(4)*abs(randn(size(X)));
   %X1=X+mat2gray(poissrnd(sigma(3),size(X)));
    A=[A;X1];
end
maxk=16;

%% UoI_NMF
[mdlstrct] = basicNMF_KL_UoI_DBcluster(A,maxk,20);

W1=mdlstrct.opt.Wopt;
H1=mdlstrct.opt.Hopt;
k=size(H1,1);


%% Basic and sparse NMF
[n,d]=size(A);
beta=[1,5,10,0.5,15];
for i=1:1
    Wr=abs(randn(n,k));
    Hr=abs(randn(k,d));
    option.beta=beta(i);
   % [W3(:,:,i),H3(:,:,i),D(:,i),~]=nmf_kl(A,k,'W0',Wr,'H0',Hr);
 [W3(:,:,i),H3(:,:,i),D(i)]=nnmf(A,k,'w0',Wr,'h0',Hr);
 [H4(:,:,i),W4(:,:,i),tElapsed,D2(i)]=sparsenmfnnls(A',k,option);
end
[~,id]=min(D(end,:));
H2=H3(:,:,1);
W2=W3(:,:,1);


[~,id1]=min(D2);
H5=H4(:,:,id1)';
W5=W4(:,:,id1)';

%% calculate nonzeros and errors
%nnzW1=nnz(W1)/n
%nnzW1=sum(sum(abs(W1)>0.0))/n
nnzW1=median(sum(abs(W1)>1.0,2))
%nnzH1=nnz(H1)/k
%nnzH1=sum(sum(abs(H1)>0.5))/k
nnzH1=median(sum(abs(H1)>0.05,2))
%nnzW2=nnz(W2)/n
%nnzW2=sum(sum(abs(W2)>1e-3))/n
nnzW2=median(sum(abs(W2)>1e-3,2))
%nnzH2=nnz(H2)/k
%nnzH2=sum(sum(abs(H2)>2e-2))/k
nnzH2=median(sum(abs(H2)>2e-1,2))

% nnzW5=sum(sum(abs(W5)>1e-3))/n
nnzW5=median(sum(abs(W5)>1e-3,2))
% %nnzH2=nnz(H2)/k
% nnzH5=sum(sum(abs(H5)>2e-2))/k
nnzH5=median(sum(abs(H5)>2e-2,2))
W11=W1;%(abs(W1)>1);
W11(W11<1)=0;
A11=W11*H1;
A22=W2*H2;

 A55=W5*H5;

figure()
for i=1:k
    subplot(4,4,i)
    H11(i,:)=mat2gray(H1(i,:));
    imshow((reshape(H11(i,:),[],32)));
    %colorbar; colormap(noeljet)
    %colormap('default')
end

%H1=H3(bestid,:);
figure()
for i=1:k
    subplot(4,4,i)
      H22(i,:)=mat2gray(H2(i,:));
    imshow((reshape(H22(i,:),[],32)));
end
% 
figure()
for i=1:k
    subplot(4,4,i)
        H55(i,:)=mat2gray(H5(i,:));
    imshow((reshape(H55(i,:),[],32)));
end
% 
% %% Basis quality
% load('Exact_16bases_swimmer.mat');
% 
% 
C1=normc(H11*Hopt');
C2=normc(H22*Hopt');
C3=normc(H55*Hopt');

[corr1,id1]=max(C1,[],2);
[corr2,id2]=max(C2,[],2);
[corr3,id3]=max(C3,[],2);
Hl1=[];j1=[];
for j=1:k
    i1=find(id1==j);
    if numel(i1)==0
        j1=[j1;j];
        continue;
    elseif numel(i1)==1
        rms1(j,1)=mean((H11(i1,:)-Hopt(j,:)).^2,2);
    else
        [~,i2]=max(corr1(i1));
        rms1(j,1)=mean((H11(i1(i2),:)-Hopt(j,:)).^2,2);
        Hl1=[Hl1;H11(setdiff(i1,i1(i2)),:)];
    end
end
if ~isempty(Hl1)
    Cl1=Hl1*Hopt(j1,:)';
    [~,il1]=max(Cl1,[],2);
    rms1(j1,1)=mean((Hl1-Hopt(j1(il1),:)).^2,2);
    %rms1=[rms1;rmsl1];
end

    
Hl2=[];j2=[];
for j=1:k
    i2=find(id2==j);
    if numel(i2)==0
        j2=[j2;j];
        continue;
    elseif numel(i2)==1
        rms2(j,1)=mean((H22(i2,:)-Hopt(j,:)).^2,2);
    else
        [~,i3]=max(corr2(i2));
        rms2(j,1)=mean((H22(i2(i3),:)-Hopt(j,:)).^2,2);
        Hl2=[Hl2;H22(setdiff(i2,i2(i3)),:)];
    end
end
if ~isempty(Hl2)
    Cl2=Hl2*Hopt(j2,:)';
    [~,il2]=max(Cl2,[],2);
    rms2(j2,1)=mean((Hl2-Hopt(j2(il2),:)).^2,2);
    %rms1=[rms1;rmsl1];
end
rms3=mean((H55-Hopt(id3,:)).^2,2);
r1=mean(rms1)
r2=mean(rms2)
 r3=mean(rms3)
% % 
% % 
figure()
plot(sort(abs(corr1)),'r*-')
hold on;
plot(sort(abs(corr2)),'bo-')
plot(sort(abs(corr3)),'gs-')
legend('UoI-NMF','basicNMF','sparseNMF')
xlabel('Bases')
ylabel('Correlation with exact bases')
title('Correlation between exact and learned bases')
% 
% 
figure()
plot(sort(rms1),'r*-')
hold on;
plot(sort(rms2),'bo-')
plot(sort(rms3),'gs-')
legend('UoI-NMF','basicNMF','sparseNMF')
xlabel('Bases')
ylabel('Mean Squared Error')
title('Mean Squared Error between exact and learned bases')


clear W1;clear W2;%clear W5;
%[W1,~]=nnmf(X,k+1,'h0',H1);
  for l=1:size(X)
            W1(l,:)= lsqnonneg(H1',X(l,:)')';
  end
%   R1=W1*H1;
%  er1=sum(X(:).*log(X(:)./R1(:)) - X(:) + R1(:))
er1=norm(X-W1*H1,'fro')

  for l=1:size(X)
            W2(l,:)= lsqnonneg(H2',X(l,:)')';
  end

 er2=norm(X-W2*H2,'fro')



%% Visualization
% r=randperm(n);
% W1=mdlstrct.opt.Wopt;
% figure()
% l1=0;
% for l=1:4
%     for i=1:4
%      subplot(4,16,i+l1)
%     imshow((reshape(H11(i+l1/4,:),[],32)));
%      subplot(4,16,i+l1+4)
%     image(imcomplement(mat2gray(reshape((abs(W1(r(i+l1/4),:))>2.01),4,[])))','CDataMapping','scaled');
%     subplot(4,16,i+l1+8)
%     imshow(mat2gray(reshape(A11(r(i+l1/4),:),[],32)));
%      subplot(4,16,i+l1+12)
%     imshow((reshape(A(r(i+l1/4),:),[],32)));
%     end
%     l1=l1+16;
% end
% set(gca,'LooseInset',get(gca,'TightInset')); 
%  for i=1:16
%      Dis1(:,:,1,i)=reshape(H11(i,:),[],32);
%      Dis2(:,:,1,i)=imcomplement(mat2gray(reshape((abs(W1(r(i),:))>1.01),4,[])));
%      Dis3(:,:,1,i)=mat2gray(reshape(A11(r(i),:),[],32));
%      Dis4(:,:,1,i)=mat2gray(reshape(A(r(i),:),[],32));
%  end
%   subplot(1,4,1)
% montage(Dis1, 'Size', [4 4]);
% subplot(1,4,2)
% montage(Dis2, 'Size', [4 4]);
% subplot(1,4,3)
% montage(Dis3, 'Size', [4 4]);
% subplot(1,4,4)
% montage(Dis4, 'Size', [4 4]);
