function [Y,q ]= Krylov_dimension(X, m, sigma, max_rank)
%% function [Y,q ]= Krylov_dimension(X, m, sigma)
% This function computes the approximate rank of a data matrix X using a
% Krylov subspace and information theroy criterion appoarch
%------------------------------------
% Input : X is the data matrix, 
%         m is the number of Lanczos steps per singular value comnputation,
%         sigma is the variance paramter of the data. 
%         max_rank is the maximum rank to terminate the iteration.
% Output: Y is the prinicpal compoments (top left singular vector 
%eigenvectors) of the data
%         q is the estimated rank.
%-----------------------------------
%%- By Shashanka Ubaru
% Cite:
% Find the dimension that counts: Fast dimension estimation and Krylov PCA
% S. Ubaru, A-K. Seghouane, and Y. Saad
% SIAM International Conference on Data Mining (SDM), 2019
%% Initialization and parameter set up

[p,n]=size(X);  % get size

IC=zeros(min(p,n),1);

Xfro=norm(X,'fro')^2; % norm of the data

Snfro=(Xfro^2-2*sigma*Xfro+p*sigma^2); % norm of the covariance


%%------set parameter
%  if(n<2*p)
%     cn=0.01*log(n);
% % elseif(n>=1*p && n<5*p)
%   Cn=sigma*sqrt(n);
%  else
%      cn=0.04*log(n);
%  end
Cn=1*log(n);  % tune thoie scaling to get optimal results.

%% Main routine

v=randn(p,1); V=v/norm(v);  % crerate a random vector for Lanczos
T=[];

for k=1:max_rank
    
    [U, V, T, Theta] = Lanczos_update(X, V, T, m);   % get the next eigenpairs using the Lanczos algorithm
    % V=V(:,k+m);
    % T=T(1:k+m,1:k+m);
    k1=min(k,length(Theta));
    IC(k)=(n/(2*sigma^2))*(Snfro-sum(Theta(1:k1)))-Cn*(p-k)*(p-k-1)/2; % compute the information criterion
    
    if (k>1)
        if (IC(k)>IC(k-1))   % 
            break;
        end
    end
end
%plot(IC)
q=k-1;   % estimated rank
if size(V,2)>q
    Y=V(:,1:q)*U(1:q,1:q);
else
    Y=V*U;   % the PCs
end

