clc
close all

%% ------------
% Main driver : An example to demonstrate the Krylov dimension approach for approximate rank estimation
%%- By Shashanka Ubaru
% Cite:
% Find the dimension that counts: Fast dimension estimation and Krylov PCA
% S. Ubaru, A-K. Seghouane, and Y. Saad
% SIAM International Conference on Data Mining (SDM), 2019
%%--------------------
%% load matrices and their singular values
load 'lpi_ceria3d.mat'
load 'lpi_ceria3d_SVD.mat'

X = Problem.A;  % data matrix
d=S.s;          %  singualar values
[p,n]=size(X);

%% Create synthetic data
% n=4000;
% k = 100;
% A=sprand(n,k,0.1);
% L=diag(5:0.5:54.5);
% sigma=0.001;
% X=A*L*A';
% X=X+sigma*sprand(n,n,0.1);

%% Set paramter
m = 10;  % number of Lanczos steps per singular value
sigma=0.01; % noise level
%% Compute rank

t1=cputime;

[Y,q] = Krylov_dimension(X, m, sigma, min(p,n)); % call main function

t2=cputime;

fprintf("Total time taken: %f secs \n",t2-t1)
fprintf("Approximate rank estiamted: %d \n", q)
%% plot the singular values and rank

%d=d.^2;  % Eigenvalues of the sample covariance.

figure()
plot(1:min(n,p),d,'bo-')
hold on
stem(q,1.1*d(1),'r*-')
legend('singular values','Estimated-rank','fontsize',16);
xlabel('i -->','fontsize',16);
ylabel('\sigma_i','fontsize',16);
title('Rank estimation using Krylov method','fontsize',16);
hold off;