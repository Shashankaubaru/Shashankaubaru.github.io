clc
close all
clear all

addpath 'XMLDatasetRead'



%% Load data
[data,label]=read_data('Bibtex/Bibtex_data.txt');
Trainid=importdata('Bibtex/bibtex_trSplit.txt');
Testid=importdata('Bibtex/bibtex_tstSplit.txt');

[d,~]=size(label); % Number of label 
k=5; % Output sparsity


%% Choose subset as training and test data

n=2000; % Number of training points
nt=500; % Number of test points

Data.train= data(:,Trainid(1:n,1));
Data.trainlabel = label(:,Trainid(1:n,1));

Data.test= data(:,Testid(1:nt,1));
Data.testlabel = label(:,Testid(1:nt,1));

%% MLGT algorithm
m=50;  %% Number of tests in Group testing

param.GT_scheme = 'expander';
param.classifier='LS';
param.kernel='linear';

Output=MLGT(Data,m,k,param);

%% Evaluation
TrainHloss=mean(Output.train_Hammloss);
TestHloss=mean(Output.test_Hammloss);
TrainPrecison=mean(Output.train_Precison);
TestPrecison=mean(Output.test_Precison~=0);
