function Output=MLGT(Data,m,k,param)
%%  output=MLGT(data,params)
% This function performs multilabel classification via. the group testing
% approach
%% ---Inputs
% Data :  Data.train = Training data points
%         Data.trainlabel = Labels corresponding to traning data
%         Data.test = Test data points
%         Data.testlabel = Labels corresponding to test data
% m = number of tests in group testing
% k = output sparsity
% param: param.GT_scheme = The type of Group testing scheme
%        param.classifier = Type of binary classifier
%        param.kernel = Kernel to be used in SVM classifier

%% -- Output
%Output :   Output.pred_trainlabel= preditcted labels for training data
%           Output.pred_testlabel= preditcted labels for test data
%           Output.train_Hammloss= Training Hamming loss
%           Output.train_Precison= Training Precison 
%           Output.test_Hammloss= Test Hamming loss
%           Output.test_Precison=  Test Precision
%-- By Shashanka Ubaru
%-- Date: 04/07/2018
%% 
if ~isfield(param,'GT_scheme')
    param.GT_scheme='expander';
end

if ~isfield(param,'classifier')
    param.classifier='LS';
end

if ~isfield(param,'kernel')
    param.kernel='linear';
end

%% Extract data and parameters 
X=Data.train;
Y=Data.trainlabel;
[p,n]=size(X);
[d,~]=size(Y);
Xtest=Data.test;
Ytest= Data.testlabel; %% only for error calculation
[~,nt]=size(Xtest);
%% Create GT matrix

switch param.GT_scheme
    case 'RScode'
        A=RScode(d,m);   % Kautz-Singleton construction
        m=size(A,1);
    case 'expander'
    A=zeros(m,d);
    for i=1:d
        r=randperm(m,k+3);
        A(r,i)=1;
    end  
    case 'sprand'
    A=zeros(m,d);
    for i=1:d
        A(:,i)=spones(sprand(m,1,(k+1)/m));
    end  
    otherwise
        error('Error: Wrong GT scheme\n');
end

%% MLGT Traning

%%-- reduce the label (group the labels)
Z=zeros(m,n);
for i=1:n
    Z(:,i)=spones(A*Y(:,i));   %Boolean OR operation
end

%%-- Train 'm' binary classifiers for the reduced labels
%%-- Get the prediction labels for traning and test data.
Y_pred=zeros(m,n);
Ytest_pred=zeros(m,nt);
X=X';
Xtest=Xtest';
for j=1:m
    z=Z(j,:)';
    if(nnz(z)==0)   %% No need to train if all labels are zeros
        Y_pred(j,:)=0;
        Ytest_pred(j,:)=0;
    else
        %%- Can use other binary classifier of your choice
        SVMSTRUCT(j) = svmtrain(full(X), full(z),'method', param.classifier,'kernel_function', param.kernel);
    end
    Y_pred(j,:)=svmclassify(SVMSTRUCT(j),full(X))';
    Ytest_pred(j,:)=svmclassify(SVMSTRUCT(j),full(Xtest))';
end

%% MLGT Prediction

%% Recover predicted training labels and compute errors
predY=zeros(d,n);
H_errtrain=zeros(n,1);
Prectrain=zeros(n,1);
for l=1:n
    yp=Y_pred(:,l);
    tp=zeros(d,1); 
    for i=1:d
        s2= sum(A(:,i)&yp);
        if (s2 ==nnz(A(:,i))), tp(i,1)=1;   end
    end
    predY(:,l)=tp;  %%predicted label
    H_errtrain(l,1)=sum(tp~=Y(:,l));
    Prectrain(l,1)=sum(tp&Y(:,l))/nnz(Y(:,l));
end

%% Recover predicted test labels and compute errors
predYtest=zeros(d,nt);
H_errtest=zeros(nt,1);
Prectest=zeros(nt,1);
for l=1:nt
    ytp=Ytest_pred(:,l);
    tp=zeros(d,1); 
    for i=1:d
        s2= sum(A(:,i)&ytp);
        if (s2 ==(nnz(A(:,i)))), tp(i,1)=1;   end
    end
    predYtest(:,l)=tp;  %%predicted label
    H_errtest(l,1)=sum(tp~=Ytest(:,l));
    Prectest(l,1)=sum(tp&Ytest(:,l))/nnz(Ytest(:,l));
end 
%% Outputs

Output.pred_trainlabel= predY;
Output.pred_testlabel= predYtest;
Output.train_Hammloss= H_errtrain;
Output.train_Precison=  Prectrain;
Output.test_Hammloss= H_errtest;
Output.test_Precison=  Prectest; 