function A=RScode(d,m)
%% q-ary Reed Solomon code  and Kautz Singleton construnction  of desired dimension 
%% Check dimension


if(m<56)
    q=8;
else
    q=16;
end

if(nchoosek(q,3)>=d)
    r=3;
else
    r=5;
end

%% Generate q array RS code
msg=nmultichoosek(1:q,r);
rm=randperm(length(msg),d);
msg=msg(rm,:);
msg = gf(msg-1,r-1);

%genpoly = rsgenpoly(q-1,4);
code = rsenc(msg,q-1,r);
C=double(code.x);
%% Convert to binary matrix

A=zeros(size(C,1),q*(q-1));
j=1;
for i=1:q-1
    for k=1:size(C,1)
        A(k,C(k,i)+j)=1;
    end
    j=j+q;
end
A=A';
