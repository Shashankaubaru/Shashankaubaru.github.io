clc
clear all
close all

%% Load the matrix
load 'Kohonen.mat'
load 'Kohonen_SVD.mat'

A = Problem.A';
ev=S.s;
[m,n]=size(A);

%% Generate Dual BCH code matrix

l=63;  %% length of the code must be 2^p-1

GENPOLY = bchgenpoly(l,45);
%generator polynomial for dual BCH(255,239)113,493,1003
poly=double(GENPOLY.x)';
[g,h]=cyclgen(l,poly);
k2=size(g,1);
k4=round(log2(n))+1;
%get all combinations of 12 binary digits
 x=de2bi(0:2^(k2)-1); %% generate all 2^k2 messages
 q=randperm(length(x));
  x=x(q(1:n),:);  %% choose n random messages
a=mod(x*g,2);  %% binary multiplication
a=a.*(-2);
b=ones(size(a)).*(1); 
Om1=b+a;    %% subsampled code matrix
D=diag(randraw('rademacher',[],n)); %% radamacher diagonal matrix
Om1=D*Om1; %% randomized subsampled code matrix

Om2=randn(n,l); % Generate Gaussian matrix for comparison

%% Main algorithm

t1=cputime();
Y1=A*Om1/sqrt(l);  %% sampling by code matrix

[Q1,~]=qr(Y1,0);   %% Get the subpace
B1=Q1'*A;         
t2=cputime();

sprintf('Time taken by BCH =%3fsecs',t2-t1) 
%clear B1; clear Y1;
clear Om1;


t1=cputime();
Y2=A*Om2;     %% sampling by Gaussian matrix

[Q2,~]=qr(Y2,0);
B2=Q2'*A;
t2=cputime();

sprintf('Time taken by Gaussian =%3fsecs',t2-t1) 
%clear B2; clear Y2;
clear Om2;


%% SVD computation in sampled space
[U1,S1,V1]=svd(B1,'econ');  %% SVD for code matrix sampling

[U2,S2,V2]=svd(B2,'econ'); %% SVD for Gaussian matrix sampling

S5=ev(1:l);   %% Exact singular values

%% Error calculation and plots
 e1=svds((A-Q1*(Q1'*A)),1) %% Spectral norm error for code matrix sampling
 e2=svds((A-Q2*(Q2'*A)),1)
 e=ev(l+1)   %% error lower bound
 
% plot  sinuglar values obtained
figure();
plot((S5),'k-*');
hold on;
plot(diag(S1),'r-o');
plot((diag(S2)),'b-s');

ylabel('singular values \sigma_i');
xlabel('i');
legend('by svds','by dual BCH','by Gaussian')




