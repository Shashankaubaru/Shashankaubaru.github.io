%% Computes the approximate rank of a sample matrix using Chebyshev filters
% By Shashanka Ubaru and Yousef Saad

close all
%clear
%%-------------------- NOTE: small gap requires very high degree
%%    parameters
deg   = 50;
eps=0.01;
nvecs = 30;
AutoGap=1;
Npts=100;

%plot flags
bDo_plot = 1;
Filter_plot=1;
%%--------------------
%% load matrices and their singular values
 load 'netz4504.mat'
load 'netz4504_SVD.mat'
  X = Problem.A;
  n = size(X,2);
d=S.s;
A = X'*X;
d = d .^ 2;
%% Find threshold and rank
fprintf('Finding threshold and rank using KPM of deg = %d\n',deg);

n = size(A,2);
d = sort(d);
%d(1)=0;
%%-------------------- lmin - lmax
lmin = d(1)-0.00001;
lmax = d(n)+0.00001;
%%--------------------
t1=cputime;
[r,g,zz,z1,xx,yy]=KPM_DOS_and_Rank(A,lmin,lmax,deg,nvecs,Npts,AutoGap);
%eig(full(A),10000);
t2=cputime;
fprintf('Estimated threshold      = %7.5f \n',g) ;
fprintf('Estimated rank      = %7.5f \n',r) ;
num = sum(d > (g));
fprintf('Exact count above threshold = %7.5f \n',num)
t2-t1
%% PLots
if (bDo_plot)
    figure(1)
    clf
    hold on
    plot(xx(1:end), yy(1:end),'b-o','linewidth',2);
    %axis([0 4.5 0 1])
    txt = sprintf('DOS with KPM, deg M = %3d', deg );
    title(txt,'fontsize',20);
    xlabel('\lambda','fontsize',20);
    ylabel('\phi ( \lambda ) ','fontsize',20);
    box on
    hold off
end
if (Filter_plot)
    figure(2)
    %%-------------------- plotting -- plot line cumulative estimate
    plot(1:nvecs,zz,'k-','linewidth',2)
    hold on;
    %%-------------------- plot each value (Pv,v) for each sample vect.
    plot(1:nvecs,z1,'o','linewidth',2)
    %%-------------------- plot exact count - straight line
    plot([0 nvecs], [num num], 'r--', 'linewidth',2)
    %%----------------------- plot standard deviation of z1
    titt = sprintf('Chebyshev filter method');
    xlab = sprintf('Number of vectors (1 -> %d)',nvecs);
    ylab = sprintf('Estimed # eigenvalues in interval');
    title(titt,'fontname','Helvetica','fontsize',20);
    xlabel(xlab,'fontname','Helvetica','fontsize',20);
    ylabel(ylab,'fontname','Helvetica','fontsize',20);
    set(gca, 'FontSize', 20 );
    hleg = legend('Cumulative Filter','(Pv,v)','Exact');
    %%              'Filter + sigma','Filter - sigma');
    set(hleg,'FontSize',22,'FontWeight','normal','location',...
        'northeast','Color','none' );
end
