%% Computes the approximate rank of a sample matrix using
%% Lanczos approximation
% By Shashanka Ubaru and Yousef Saad

close all 
%clear
%%-------------------- NOTE: small gap requires very high degree
%%    parameters
Mdeg   = 50;
eps=0.01;
nvec = 30;
AutoGap=1;
Npts=100;

%plot flags
bDo_plot = 1;
Lanc_plot=1;
%%--------------------
%% load matrices and their singular values
 load 'netz4504.mat'
load 'netz4504_SVD.mat'
  X = Problem.A;
  n = size(X,2);
d=S.s;
A = X'*X;
d = d .^ 2;

%% Parameters for Lanczos
sigma = 0.025;

n = size(A,2);
d = sort(d);
%%--------------------lmin, lmax
lm = d(1);
lM = d(end);

x = linspace( lm, lM, Npts )';
y = zeros(Npts,1);
h = x(2)-x(1);

%%-------------------- if gaussian smaller than tol ignore point.
tol    = 1.e-02;
width  = sigma*sqrt(-2 *log(tol));
sigma2 = 2*sigma^2;

%% Find threshold and rank by Lanczos Approximation
fprintf('Finding threshold and rank using Lanczos of deg = %d\n',Mdeg);
T=zeros(Mdeg,nvec);
G=zeros(Mdeg,nvec);
z1=zeros(nvec,1);
zz=zeros(nvec,1);

for m = 1 : nvec
    w = randn(size(A,1),1);
    v0 = w /norm(w);
    [H,V,f] = arnoldi_k(A,v0,Mdeg);
    H = (H+H')/2;
    [eigvec,D]=eig(H);
    theta  = real(diag(D));
    gamma2 = eigvec(1,:).^2;
    T(:,m)=theta;
    G(:,m)=gamma2;
     for i=1:size(theta)
        t = theta(i);
        %% first point to consider

        ind = find( abs(x - t) < width );
        y(ind) = y(ind) + gamma2(i) * exp(-(x(ind)-t).^2/sigma2);
     end
end

xx  = x;
yy  = y';
yy  = yy / (sum(yy)*(xx(2)-xx(1)));

%% compute gap
if(AutoGap)
     g = find_gap(xx,yy,n);    
else
    g=0.512; % set a threshold
end

%% Compute the eigencount (the rank)
 cnt_est=0;
for m=1:nvec
    t=T(:,m);
    gam=G(:,m); 
    count=sum(gam(t<=g));
    
    z1(m) = (1-count)*n;
    cnt_est = (cnt_est+(1-count));
    zz(m) = n*(cnt_est/m);

end
r=zz(nvec);


%% display results and plots
fprintf('Estimated threshold      = %7.5f \n',g) ;
fprintf('Estimated rank      = %7.5f \n',r) ;
num = sum(d > g);
fprintf('Exact count above threshold = %7.5f \n',num)

%% DOS plot
if (bDo_plot)
    figure()
    clf
    hold on
    plot(xx, yy,'b-o','linewidth',2);
    axis tight
    txt = sprintf('Lanczos w. $\\sigma$ = %5.2f, deg = %3d',...
        sigma, Mdeg);
    title(txt);
    legend('Lanczos');
    xlabel('\lambda');
    ylabel('\phi(\lambda)');
    box on
    hold off
    %% eigenvalue plot
%     figure();
%     plot((flipud(d)),'b-o','linewidth',2);
%     ylabel('\lambda_i','fontsize',20);
%     xlabel('i','fontsize',20);
%     title('Matrix Spectrum','fontsize',20);
end

%% approximate rank plot
if (Lanc_plot)
    figure()
    % set(figure,'defaulttextinterpreter','latex');
    %%-------------------- plotting -- plot line cumulative estimate
    plot(1:nvec,zz,'k-','linewidth',2)
    hold
    %%-------------------- plot each value (Pv,v) for each sample vect.
    plot(1:nvec,z1,'o','linewidth',2)
    %%-------------------- plot exact count - straight line
    plot([0 nvec], [num num], 'r--', 'linewidth',2)
    %%----------------------- plot standard deviation of z1
    titt = sprintf('Lanczos Approximation (matrix size=%d) ', n);
    xlab = sprintf('Number of vectors (1 -> %d)',nvec);
    ylab = sprintf('Estimed # eigenvalues in interval');
    title(titt,'fontname','Helvetica','fontsize',20);
    xlabel(xlab,'fontname','Helvetica','fontsize',20);
    ylabel(ylab,'fontname','Helvetica','fontsize',20);
    set(gca, 'FontSize', 20 );
    hleg = legend('Cumulative Avg','$(r_\varepsilon)_\ell$','Exact');
    %%              'Filter + sigma','Filter - sigma');
    set(hleg,'FontSize',22,'FontWeight','normal','location',...
        'northeast','Color','none' );
end